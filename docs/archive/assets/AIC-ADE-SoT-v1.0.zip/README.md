# AIC-ADE Single Source of Truth (SoT) Index

**Product:** AIC-ADE (Agentic Development Environment)  
**Repository:** `AI-Company`  
**Version:** SoT v1.0  

This directory contains the official permanent engineering constitution of **AIC-ADE**. Every autonomous software decision, architecture change, worker specification, and release policy must follow these documents.

---

## Document Map

| # | Document Title | File |
|---|---|---|
| 00 | Product Constitution | [`00_PRODUCT_CONSTITUTION.md`](00_PRODUCT_CONSTITUTION.md) |
| 01 | Product Vision | [`01_PRODUCT_VISION.md`](01_PRODUCT_VISION.md) |
| 02 | Product Identity | [`02_PRODUCT_IDENTITY.md`](02_PRODUCT_IDENTITY.md) |
| 03 | Architecture | [`03_ARCHITECTURE.md`](03_ARCHITECTURE.md) |
| 04 | AIC Runtime | [`04_AIC_RUNTIME.md`](04_AIC_RUNTIME.md) |
| 05 | Project Runtime | [`05_PROJECT_RUNTIME.md`](05_PROJECT_RUNTIME.md) |
| 06 | Worker Runtime | [`06_WORKER_RUNTIME.md`](06_WORKER_RUNTIME.md) |
| 07 | Hermes Dispatcher | [`07_HERMES_DISPATCHER.md`](07_HERMES_DISPATCHER.md) |
| 08 | Worker Specification | [`08_WORKER_SPECIFICATION.md`](08_WORKER_SPECIFICATION.md) |
| 09 | Department Specification | [`09_DEPARTMENT_SPECIFICATION.md`](09_DEPARTMENT_SPECIFICATION.md) |
| 10 | Provider Runtime | [`10_PROVIDER_RUNTIME.md`](10_PROVIDER_RUNTIME.md) |
| 11 | Conversation Runtime | [`11_CONVERSATION_RUNTIME.md`](11_CONVERSATION_RUNTIME.md) |
| 12 | Memory Runtime | [`12_MEMORY_RUNTIME.md`](12_MEMORY_RUNTIME.md) |
| 13 | Knowledge Runtime | [`13_KNOWLEDGE_RUNTIME.md`](13_KNOWLEDGE_RUNTIME.md) |
| 14 | Task Runtime | [`14_TASK_RUNTIME.md`](14_TASK_RUNTIME.md) |
| 15 | Timeline Runtime | [`15_TIMELINE_RUNTIME.md`](15_TIMELINE_RUNTIME.md) |
| 16 | Event Runtime | [`16_EVENT_RUNTIME.md`](16_EVENT_RUNTIME.md) |
| 17 | Workspace Runtime | [`17_WORKSPACE_RUNTIME.md`](17_WORKSPACE_RUNTIME.md) |
| 18 | UI Constitution | [`18_UI_CONSTITUTION.md`](18_UI_CONSTITUTION.md) |
| 19 | Design System | [`19_DESIGN_SYSTEM.md`](19_DESIGN_SYSTEM.md) |
| 20 | Engineering Workflow | [`20_ENGINEERING_WORKFLOW.md`](20_ENGINEERING_WORKFLOW.md) |
| 21 | Project Structure | [`21_PROJECT_STRUCTURE.md`](21_PROJECT_STRUCTURE.md) |
| 22 | Folder Structure | [`22_FOLDER_STRUCTURE.md`](22_FOLDER_STRUCTURE.md) |
| 23 | Database Specification | [`23_DATABASE_SPECIFICATION.md`](23_DATABASE_SPECIFICATION.md) |
| 24 | API Specification | [`24_API_SPECIFICATION.md`](24_API_SPECIFICATION.md) |
| 25 | Testing Constitution | [`25_TESTING_CONSTITUTION.md`](25_TESTING_CONSTITUTION.md) |
| 26 | Release Engineering | [`26_RELEASE_ENGINEERING.md`](26_RELEASE_ENGINEERING.md) |
| 27 | Security Constitution | [`27_SECURITY_CONSTITUTION.md`](27_SECURITY_CONSTITUTION.md) |
| 28 | Performance Constitution | [`28_PERFORMANCE_CONSTITUTION.md`](28_PERFORMANCE_CONSTITUTION.md) |
| 29 | Product State | [`29_PRODUCT_STATE.md`](29_PRODUCT_STATE.md) |
| 30 | Roadmap | [`30_ROADMAP.md`](30_ROADMAP.md) |
| 31 | Architecture Decisions | [`31_ARCHITECTURE_DECISIONS.md`](31_ARCHITECTURE_DECISIONS.md) |
| 32 | Autonomous Engineering | [`32_AUTONOMOUS_ENGINEERING.md`](32_AUTONOMOUS_ENGINEERING.md) |
| 33 | Glossary | [`33_GLOSSARY.md`](33_GLOSSARY.md) |
| 34 | Future Vision | [`34_FUTURE_VISION.md`](34_FUTURE_VISION.md) |
