# 01 — Product Vision

**Product:** AIC-ADE  
**Vision Objective:** Autonomous AI Engineering Company Operating Core  

---

## 1. Paradigm Shift: Beyond AI IDEs

Traditional AI coding assistants (Copilot, Cursor, Windsurf) act as inline autocomplete or chat sidebars inside conventional text editors. They rely on manual developer prompt-steering for every single line of code.

AIC-ADE redefines software engineering by providing an **Agentic Development Environment**:
- **Project-Centric Execution:** Software is built by a specialized team of 15 virtual AI workers organized into 10 engineering departments.
- **Autonomous Lifecycle:** From intake and discovery to planning, implementation, QA testing, code review, and distribution, the runtime drives the pipeline forward.
- **Engine-First Architecture:** The React/Electron desktop UI is a window into a persistent Python/FastAPI backend core (`aic-platform`).

---

## 2. Core Operating Principles

1. **Conversational Intake, Structured Execution:** Hermes conducts natural clarification discussions with the user to refine intent, but once confirmed, tasks execute through structured Finite State Machines (FSM).
2. **Determinism and Verifiability:** Every engineering claim made by a worker must be backed by verifiable execution artifacts (unit test output, linters, diffs, build binaries).
3. **Multi-Model Orchestration (BYOK):** Users bring their own API keys (OpenAI, Anthropic, OpenRouter, VansRouter, Ollama). The platform automatically routes tasks to the best-suited model tier.
