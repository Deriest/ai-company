# 03 — Architecture

**Architecture Style:** Desktop-Sidecar Monolith with Async Event Loop  

---

## 1. System Component Diagram

```
+-------------------------------------------------------------------+
|                        AIC ADE Desktop (Electron)                 |
|  +-------------------------------------------------------------+  |
|  |                 React 19 Renderer (Vite 6)                  |  |
|  |  [Overview] [Chat] [Workspace] [LiveCompany] [Settings]    |  |
|  +------------------------------+------------------------------+  |
|                                 | IPC / Preload                   |
|  +------------------------------v------------------------------+  |
|  |                   Electron Main Process                    |  |
|  |       Sidecar Manager | Auto Updater | Native Dialogs       |  |
|  +------------------------------+------------------------------+  |
+---------------------------------|---------------------------------+
                                  | HTTP / SSE (Port 8000)
+---------------------------------v---------------------------------+
|                       aic-platform (Python 3.12)                  |
|  +-------------------------------------------------------------+  |
|  |                  FastAPI Backend Daemon                     |  |
|  |  /api/conversations  /api/tasks  /api/projects  /api/llm   |  |
|  +------------------------------+------------------------------+  |
|                                 |                                 |
|  +------------------------------v------------------------------+  |
|  |                    Conversation Engine                      |  |
|  |          Intent Classifier | Task Dispatcher                |  |
|  +------------------------------+------------------------------+  |
|                                 |                                 |
|  +------------------------------v------------------------------+  |
|  |                     Provider Manager                        |  |
|  |       Smart Tier Fallback (Thinker -> Crafter -> Sprinter)  |  |
|  +------------------------------+------------------------------+  |
|                                 | Async SQLite                    |
|  +------------------------------v------------------------------+  |
|  |                 Database Storage (aic.db)                   |  |
|  +-------------------------------------------------------------+  |
+-------------------------------------------------------------------+
```

## 2. Key Subsystem Interactions

- **IPC & Health Check:** Main process launches `aic-platform` as a sidecar process. Preload script polls `http://127.0.0.1:8000/api/health` until ready.
- **REST & SSE Streaming:** Chat messages stream back real-time text chunks using SSE (`/api/conversations/{id}/messages/stream`).
- **Provider Resilience:** Calls to LLM models go through `ProviderManager`, which implements exponential backoff and tier fallback.
