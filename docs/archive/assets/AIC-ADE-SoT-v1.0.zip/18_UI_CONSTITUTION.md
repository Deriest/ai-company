# 18 — UI Constitution

**Subsystem:** Desktop Frontend Architecture  
**Framework:** React 19, Tailwind / Custom Dark CSS  

---

## 1. Principles of Interface Design

1. **Engineering-First:** The UI is an engineering workspace, not a marketing page. Data density, typography, and contrast must prioritize readability.
2. **Dark-First Theme:** Uses high-contrast dark palette variables (`--void: #05060a`, `--surface-0: #0a0c12`, `--surface-1: #10141c`, `--surface-2: #161c28`, `--accent: #3ddc97`, `--accent-2: #5b8cff`).
3. **No Synthetic or Placeholder UI:** All lists, metrics, worker states, and status badges reflect real backend data from `aic-platform`. Fake progress bars and synthetic placeholder strings are prohibited.
4. **Keyboard-First Navigation:** Global shortcuts (`Ctrl+K` Command Palette, `Ctrl+L` Chat, `Ctrl+S` Save File, `Ctrl+B` Toggle Dock, `?` Shortcut Help).
