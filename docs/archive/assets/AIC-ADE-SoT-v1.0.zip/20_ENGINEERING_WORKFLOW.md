# 20 — Engineering Workflow

**Subsystem:** End-to-End Pipeline Execution  

---

## 1. Pipeline Stages

```
 ┌─────────────┐     ┌─────────────┐     ┌─────────────┐
 │  Discovery  │ ──► │  Planning   │ ──► │ Execution   │
 └─────────────┘     └─────────────┘     └─────────────┘
                                                │
 ┌─────────────┐     ┌─────────────┐            │
 │  Delivery   │ ◄── │Verification │ ◄──────────┘
 └─────────────┘     └─────────────┘
```

1. **Discovery:** Clarifying user intent, checking requirement completeness against mandatory checklist.
2. **Planning:** Rex & PM break requirements into structured task specifications and architectural decisions.
3. **Execution:** Backend, Frontend, and Database workers write code artifacts inside task workspaces.
4. **Verification:** QA & Security run automated test suites, static analysis, and code reviews.
5. **Delivery:** Code diffs are merged, documentation updated, and distribution artifacts generated.
