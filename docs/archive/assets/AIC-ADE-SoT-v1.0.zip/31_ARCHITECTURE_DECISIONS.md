# 31 — Architecture Decision Records (ADRs)

---

## ADR-001: Separation of Operating Core and Dispatcher Worker

- **Status:** Accepted  
- **Context:** Early designs confused Hermes with the entire runtime application.
- **Decision:** Explicitly separate `AIC Runtime` (the operating backend core) from `Hermes` (the Dispatcher Worker). Hermes coordinates engineering tasks but does not own database models or execute direct code changes.

---

## ADR-002: Elimination of Default Model in Favor of Smart Tier Fallback

- **Status:** Accepted  
- **Context:** Single "Default Model" assignments failed when rate limits or context windows were exceeded.
- **Decision:** Require explicit tier assignments (`Thinker`, `Crafter`, `Sprinter`) and implement automatic fallback routing (`Thinker` -> `Crafter` -> `Sprinter`).

---

## ADR-003: Local Update HTTP Distribution Server

- **Status:** Accepted  
- **Context:** Automated updates must function reliably across LAN environments without external cloud lock-in.
- **Decision:** Serve release binaries and `latest.json` over a local HTTP server (`http://192.168.2.10:8088`), verifying SHA256 checksums before initiating installation.

---

## ADR-004: Multi-Agent Parallel Execution & AST Code Intelligence Core

- **Status:** Accepted  
- **Context:** Roadmap milestones v1.2.x and v1.3.x require simultaneous subtask worker execution and static AST analysis for codebases.
- **Decision:** Implement `ParallelDispatcher` (`dispatcher/parallel.py`) to execute independent subtasks concurrently using `asyncio.gather`, and `ASTAnalyzer` (`backend/ast_analyzer.py`) for extracting classes, functions, args, and imports across Python and TypeScript/JavaScript source files.
